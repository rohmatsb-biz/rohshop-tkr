Original file from here = \
https://github.com/rohmatsb-biz/tekiro/blob/main/%E3%83%AC%E3%82%B9%E3%82%AD%E3%82%BB%E3%83%86%E3%82%A3%E3%83%AF%E3%83%B3/menu.zip
